# Noir TV — Android TV source project

## Build an APK

1. Install Android Studio on Windows/macOS/Linux.
2. Open this `NoirTV` folder as a project.
3. Let Android Studio install Android SDK 35 and Gradle dependencies.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find `app/build/outputs/apk/debug/app-debug.apk` and sideload it onto the Chromecast.

This is a **source-code prototype**, not a verified APK. It has not been compiled or tested on a Chromecast.

## What works in source
- Dark TV home screen with Android TV, Nintendo Switch, Art Mode, TV Settings buttons and a live clock.
- D-pad focus and Android TV app enumeration/launching.
- Gallery listing of 150 named paintings; arrow-key browsing and optional gold-colored border.
- First five artworks have **unverified** Wikimedia Commons image URLs that require internet; other paintings currently have metadata only, not embedded images.

## Important limitations
- **Nintendo Switch HDMI-CEC input switching is not implemented**. Android third-party apps generally lack a public API to select HDMI 2 on arbitrary TVs. The button opens an explanatory dialog with a best-effort TV input settings intent.
- The 150 paintings are **not preloaded offline**. To fulfill the original specification, obtain and bundle legally reusable image assets, verify attribution/license, and update the art display to read from `assets` or packaged resources.
- Home launcher registration is included but default-home behavior depends on Chromecast firmware and user settings.
- The interface approximates the approved design; exact pixel matching and device testing are still needed.
